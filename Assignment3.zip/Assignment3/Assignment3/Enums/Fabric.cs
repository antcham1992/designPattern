﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3.Enums
{
    public enum Fabric
    {
        CASHMERE,
        COTTON,
        LINEN,
        POLYESTER,
        RAYON,
        SILK,
        WOOL
    }
}
