﻿using Assignment3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3.PaymentMethodStrategy
{
    internal class BankTranferStrategy : IPaymentMethodStrategy
    {

        public void Discount(Tshirt tshirt, decimal? percentage)
        {
            if (percentage == null)
            {
                tshirt.Price = tshirt.Price - tshirt.Price * 0.01m;
            }
            else
            {
                tshirt.Price = tshirt.Price - tshirt.Price * (decimal)percentage;
            }
        }



        public bool Pay(decimal amount)
        {
            if (amount<0m||amount>1000)
            {
                Console.WriteLine($"Paying {amount } using Bank tranfer decline");
                return false;
            }
            else
            {
                Console.WriteLine($"Paying {amount } using Bank tranfer accepted");
                return true;
            }
        }
    }
}
