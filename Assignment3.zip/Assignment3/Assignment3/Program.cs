﻿using Assignment3.Enums;
using Assignment3.EshopContext;
using Assignment3.Models;
using Assignment3.PaymentMethodStrategy;
using Assignment3.VariationStrategy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            IEnumerable<IVariationStrategy> shopNormalVariations = new List<IVariationStrategy>()
              {
                  new ColorVariationNormalStrategy(),
                  new FabricVariationNormalStrategy(),
                  new SizeVariationNormalStrategy(),

              };

            Tshirt tshirt = new Tshirt(Color.BLUE, Fabric.CASHMERE, Size.XS);
            var eshop = new Eshop();
            eshop.SetVariation(shopNormalVariations);
            eshop.CalculateCost(tshirt);
           
            Console.WriteLine("Choose Payment method;");
           
            Console.WriteLine("1-Bank Transfer");
            Console.WriteLine("2-Cash");
            Console.WriteLine("3-Debit");
            Console.WriteLine("4-Exit");
            string choise = Console.ReadLine();
            switch (choise)
            {
                case "1":eshop.SetPaymentMethod(new BankTranferStrategy()); break;
                case "2":eshop.SetPaymentMethod(new cashStrategy()); break;
                case "3":eshop.SetPaymentMethod(new DebitStrategy()); break;
                case "4": Console.WriteLine("User Exit"); ; break;
               default: Console.WriteLine("Invalid Input"); break;
            }
            eshop.Discount(tshirt, 0.5m);
            eshop.PayTshirt(tshirt.Price);

    }
    }
}
