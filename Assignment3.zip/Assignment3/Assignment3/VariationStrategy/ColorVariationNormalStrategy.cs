﻿using Assignment3.Enums;
using Assignment3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3.VariationStrategy
{
    public class ColorVariationNormalStrategy : IVariationStrategy
    {

        private static Dictionary<Color, decimal> colorVariation;

        static ColorVariationNormalStrategy()
        {
            colorVariation = new Dictionary<Color, decimal>()
            {
                { Color.BLUE, 1m },
                { Color.GREEN, 2m },
                { Color.INDIGO, 4m },
                { Color.ORANGE, 8m },
                { Color.RED, 2m },
                { Color.VIOLET, 12m },
                { Color.YELLOW, 12m },
            };
        }

        public void Cost(Tshirt tshirt)
        {
            tshirt.Price += colorVariation[tshirt.Color];
        }
    }
}
