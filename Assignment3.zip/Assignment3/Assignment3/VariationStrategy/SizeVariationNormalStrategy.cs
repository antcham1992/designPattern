﻿using Assignment3.Enums;
using Assignment3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3.VariationStrategy
{
    public class SizeVariationNormalStrategy : IVariationStrategy
    {

        private static Dictionary<Size, decimal> sizeVariation;

        static SizeVariationNormalStrategy()
        {
            sizeVariation = new Dictionary<Size,decimal>()
            {
                {Size.XS, 3m },
                { Size.S, 4m },
                {Size.M, 4m },
                { Size.L, 8m },
                { Size.XL, 15m },
                {Size.XXL, 18m },
                { Size.XXXL, 12m }
            };
        }

        public void Cost(Tshirt tshirt)
        {
            tshirt.Price += sizeVariation[tshirt.Size];
        }
    }
}
